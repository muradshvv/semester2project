using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text.Json;
using System.Windows.Forms;
using System.Drawing.Imaging;

public class ChessDisplay : Form {
    const int size = 80;
    Board gameBoard = new Board();
    Dictionary<string, Image> pieceImages = new Dictionary<string, Image>();
    Image? boardBackground;
    Image? grayCircle;
    List<Point> possibleMoves = new List<Point>();
    Point selectedSquare = new Point(-1, -1);
    bool isSquareSelected = false;
    PieceColor currentTurn = PieceColor.White;
    bool isGameOver = false;
    Point enPassantSquare = new Point(-1, -1);
    string saveFilePath;

    public ChessDisplay() {
        Text = "Chess Game";
        ClientSize = new Size(size * 8, size * 8 + 50);
        DoubleBuffered = true;

        saveFilePath = Path.Combine(AppContext.BaseDirectory, "save.json");
        LoadPieceImages();
        LoadGameState();   // load saved game if it exists

        Paint += OnPaint;
        MouseClick += OnMouseClick;

        CreateControlButtons(); // add *Restart, *Save, *Exit buttons
    }

    void CreateControlButtons() {
        //restart button
        var restartButton = new Button {
            Text = "Restart",
            Size = new Size(80, 30),
            Location = new Point(10, size * 8 + 10)
        };
        restartButton.Click += (_, __) => RestartGame();
        Controls.Add(restartButton);

        //save button
        var saveButton = new Button {
            Text = "Save",
            Size = new Size(80, 30),
            Location = new Point(100, size * 8 + 10)
        };
        saveButton.Click += (_, __) => {
            SaveGameState();
            MessageBox.Show("Game saved", "Save");
        };
        Controls.Add(saveButton);

        // exit button
        var exitButton = new Button {
            Text = "Exit",
            Size = new Size(80, 30),
            Location = new Point(190, size * 8 + 10)
        };
        exitButton.Click += (_, __) => {
            if (MessageBox.Show("Save before exit?", "Exit", MessageBoxButtons.YesNo) == DialogResult.Yes) {
                SaveGameState();
            }
            Application.Exit();
        };
        Controls.Add(exitButton);
    }

    // loads the board background and piece images from /pngs
    void LoadPieceImages() {
        string imagesFolder = Path.Combine(AppContext.BaseDirectory, "pngs");
        boardBackground = Image.FromFile(Path.Combine(imagesFolder, "board.png"));
        grayCircle = Image.FromFile(Path.Combine(imagesFolder, "gray_circle.png"));
        string[] colors = { "white", "black" };
        string[] pieces = { "pawn", "rook", "knight", "bishop", "queen", "king" };
        foreach (var color in colors) {
            foreach (var piece in pieces) {
                pieceImages[$"{color}_{piece}"] = Image.FromFile(Path.Combine(imagesFolder, $"{color}_{piece}.png"));
            }
        }
        pieceImages["white_king_check"] = Image.FromFile(Path.Combine(imagesFolder, "white_king_check.png"));
        pieceImages["black_king_check"] = Image.FromFile(Path.Combine(imagesFolder, "black_king_check.png"));
    }

    // draws the board, pieces, circles, and selection highlight
    void OnPaint(object? sender, PaintEventArgs e)
    {
        var graphics = e.Graphics;
        if (boardBackground != null) graphics.DrawImage(boardBackground, 0, 0, size * 8, size * 8); //empty  board

        bool isWhiteInCheck = gameBoard.IsKingInCheck(PieceColor.White);
        bool isBlackInCheck = gameBoard.IsKingInCheck(PieceColor.Black);

        //drawing every piece
        for (int row = 0; row < 8; row++)
        {
            for (int col = 0; col < 8; col++)
            {
                var piece = gameBoard.Cells[row, col];
                if (piece == null) continue;
                string key = (piece.Color == PieceColor.White ? "white_" : "black_") + piece.GetType().Name.ToLower();
                if (piece is King)
                {
                    if (piece.Color == PieceColor.White && isWhiteInCheck) key = "white_king_check";
                    if (piece.Color == PieceColor.Black && isBlackInCheck) key = "black_king_check";
                }
                if (pieceImages.TryGetValue(key, out var img))
                {
                    graphics.DrawImage(img, col * size, row * size, size, size);
                }
            }
        }

        //movement hints (gray circle)
        if (possibleMoves.Count > 0)
        {
            var ia = new ImageAttributes();
            ia.SetColorMatrix(new ColorMatrix { Matrix33 = 0.5f });
            int circleSize = size / 4;
            int offset = (size - circleSize) / 2;
            foreach (var p in possibleMoves)
            {
                var dest = new Rectangle(p.X * size + offset, p.Y * size + offset, circleSize, circleSize);
                if (grayCircle != null) graphics.DrawImage(grayCircle, dest, 0, 0, grayCircle.Width, grayCircle.Height, GraphicsUnit.Pixel, ia);
            }
        }

        // selection highlighter
        if (isSquareSelected)
        {
            using var highlightPen = new Pen(Color.White, 4);
            graphics.DrawRectangle(highlightPen, selectedSquare.X * size, selectedSquare.Y * size, size, size);
        }
        
        // turn identifier pawn
        string pawnKey = currentTurn == PieceColor.White ? "white_pawn" : "black_pawn";
        if (pieceImages.TryGetValue(pawnKey, out var turnPawn)) {
            int pawnSize = size / 2;
            int x = size * 8 - pawnSize - 10;
            int y = size * 8 + 10;
            graphics.DrawImage(turnPawn, x, y, pawnSize, pawnSize);
        }
    }

    // handles mouse clicks for selecting and moving pieces
    void OnMouseClick(object? sender, MouseEventArgs e) {
        if (isGameOver) return;
        int col = e.X / size;  //finding the col and row of the mouse click
        int row = e.Y / size;
        if (col < 0 || col > 7 || row < 0 || row > 7) return;

        var clickedPiece = gameBoard.Cells[row, col];
        
        // select/reselect
        if (clickedPiece != null && clickedPiece.Color == currentTurn)
        {
            SelectPiece(row, col, clickedPiece);
            return;
        }

        //attempting move
        if (!isSquareSelected) return;
        AttemptMove(row, col);
    }

    void SelectPiece(int row, int col, Piece clickedPiece) {
        selectedSquare = new Point(col, row);
        isSquareSelected = true;
        possibleMoves.Clear();
        for (int er = 0; er < 8; er++)
            for (int ec = 0; ec < 8; ec++)
            {
                if (er == row && ec == col) continue;
                if (clickedPiece.IsValidMove(row, col, er, ec, gameBoard.Cells!))
                {
                    var sim = gameBoard.CloneCells(); //simulated board for ensuring king's safety
                    sim[er, ec] = sim[row, col];
                    sim[row, col] = null;
                    if (!gameBoard.WouldKingBeInCheck(sim, currentTurn))
                        possibleMoves.Add(new Point(ec, er));
                }
            }
        Invalidate(); //redraw 
    }

    void AttemptMove(int row, int col) {
        var from = selectedSquare;
        var sel = gameBoard.Cells[from.Y, from.X]; // selected piece
        if (sel == null || sel.Color != currentTurn) return;

        bool valid = false, enPassant = false;
        
        if (sel.IsValidMove(from.Y, from.X, row, col, gameBoard.Cells!)) //check in simulated board if check happens after playing
        {
            var sim = gameBoard.CloneCells();
            sim[row, col] = sim[from.Y, from.X];
            sim[from.Y, from.X] = null;
            if (!gameBoard.WouldKingBeInCheck(sim, currentTurn))
                valid = true;
        }
        else if (sel is Pawn && enPassantSquare.X >= 0)
        {
            if (CheckEnPassant(from, row, col, ref enPassant))
                valid = true;
        }

        if (valid) {
            ExecuteMove(from, row, col, sel, enPassant);
        } else {
            Invalidate();
        }
    }

    bool CheckEnPassant(Point from, int row, int col, ref bool enPassant) {
        int d = currentTurn == PieceColor.White ? 1 : -1;
        if (row == enPassantSquare.Y && col == enPassantSquare.X &&
            Math.Abs(from.X - col) == 1 && from.Y + d == row &&
            gameBoard.Cells[from.Y, col] is Pawn adj && adj.Color != currentTurn) {

            var sim = gameBoard.CloneCells();
            int capRow = currentTurn == PieceColor.White ? row - 1 : row + 1;
            sim[capRow, col] = null;
            sim[row, col] = sim[from.Y, from.X];
            sim[from.Y, from.X] = null;
            
            if (!gameBoard.WouldKingBeInCheck(sim, currentTurn))
            {
                enPassant = true;
                return true;
            }
        }
        return false;
    }

    void ExecuteMove(Point from, int row, int col, Piece sel, bool enPassant) {
        if (enPassant) {
            int cap = currentTurn == PieceColor.White ? row - 1 : row + 1;
            gameBoard.Cells[cap, col] = null;
        }
        if (sel is King && Math.Abs(col - from.X) == 2)
            HandleCastling(from, col, sel);

        gameBoard.Cells[row, col] = sel;
        gameBoard.Cells[from.Y, from.X] = null!;
        if (sel is King km) km.HasMoved = true;
        if (sel is Rook rm) rm.HasMoved = true;

        if (sel is Pawn && Math.Abs(row - from.Y) == 2)
            enPassantSquare = new Point(col, (row + from.Y) / 2);
        else
            enPassantSquare = new Point(-1, -1);

        if (sel is Pawn && ((sel.Color == PieceColor.White && row == 7) || (sel.Color == PieceColor.Black && row == 0)))
            ShowPromotion(row, col, sel.Color);

        currentTurn = currentTurn == PieceColor.White ? PieceColor.Black : PieceColor.White;
        isSquareSelected = false;
        possibleMoves.Clear();
        Invalidate();
        Refresh();

        if (gameBoard.IsCheckmate(currentTurn)) {
            MessageBox.Show(currentTurn + " is checkmated!", "Checkmate");
            isGameOver = true;
        } else if (gameBoard.IsStalemate(currentTurn)) {
            MessageBox.Show("Stalemate!", "Draw");
            isGameOver = true;
        } else if (gameBoard.IsInsufficientMaterial()) {
            MessageBox.Show("Insufficient material!", "Draw");
            isGameOver = true;
        }
    }

    // moving the rook when castling
    void HandleCastling(Point from, int newCol, Piece king) {
        int rookCol = newCol > from.X ? 7 : 0;
        int targetCol = newCol > from.X ? newCol - 1 : newCol + 1;
        if (gameBoard.Cells[from.Y, rookCol] is Rook rook && !((King)king).HasMoved && !rook.HasMoved) {
            gameBoard.Cells[from.Y, targetCol] = rook;
            gameBoard.Cells[from.Y, rookCol] = null;
            rook.HasMoved = true;
        }
    }

    // promotion dialog
    void ShowPromotion(int row, int col, PieceColor color) {
        var promotion = new Promotion(color) { ClientSize = new Size(400, 120) };
        if (promotion.ShowDialog() == DialogResult.OK) {
            switch (promotion.SelectedPiece) {
                case "Rook":   gameBoard.Cells[row, col] = new Rook(color);   break;
                case "Bishop": gameBoard.Cells[row, col] = new Bishop(color); break;
                case "Knight": gameBoard.Cells[row, col] = new Knight(color); break;
                default:        gameBoard.Cells[row, col] = new Queen(color);  break;
            }
        }
    }

    //resets the board
    void RestartGame() {
        gameBoard.SetupDefaultPosition();
        currentTurn = PieceColor.White;
        isSquareSelected = false;
        isGameOver = false;
        enPassantSquare = new Point(-1, -1);
        possibleMoves.Clear();
        Invalidate();
    }

    // saving the current game
    void SaveGameState() {
        var piecesList = new List<object>();
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                var piece = gameBoard.Cells[r, c];
                if (piece != null) {
                    piecesList.Add(new {
                        Row = r,
                        Column = c,
                        Type = piece.GetType().Name,
                        Color = piece.Color.ToString(),
                        HasMoved = piece is King k ? k.HasMoved :
                                   piece is Rook ro ? ro.HasMoved : (bool?)null
                    });
                }
            }
        }

        var state = new {
            Turn = currentTurn.ToString(),
            EnPassantX = enPassantSquare.X,
            EnPassantY = enPassantSquare.Y,
            Pieces = piecesList
        };

        File.WriteAllText(saveFilePath, JsonSerializer.Serialize(state, new JsonSerializerOptions { WriteIndented = true }));
    }

    // loads the game state from a JSON file if it exists
    void LoadGameState() {
        if (!File.Exists(saveFilePath)) return;
        try {
            var json = File.ReadAllText(saveFilePath);
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;

            if (!root.TryGetProperty("Pieces", out var piecesArray) ||
                !root.TryGetProperty("Turn", out var turnProp)) {
                MessageBox.Show("Invalid save file: missing core fields.", "Load Error");
                return;
            }

            // clear board
            for (int r = 0; r < 8; r++)
                for (int c = 0; c < 8; c++)
                    gameBoard.Cells[r, c] = null!;

            var occupied = new HashSet<(int, int)>();
            foreach (var ps in piecesArray.EnumerateArray()) {
                int r = ps.GetProperty("Row").GetInt32();
                int c = ps.GetProperty("Column").GetInt32();
                if (r < 0 || r > 7 || c < 0 || c > 7 || occupied.Contains((r, c))) continue;

                string typeName = ps.GetProperty("Type").GetString()!;
                Piece? newPiece = typeName switch {
                    "Pawn"   => new Pawn(Enum.Parse<PieceColor>(ps.GetProperty("Color").GetString()!)),
                    "Rook"   => new Rook(Enum.Parse<PieceColor>(ps.GetProperty("Color").GetString()!)),
                    "Knight" => new Knight(Enum.Parse<PieceColor>(ps.GetProperty("Color").GetString()!)),
                    "Bishop" => new Bishop(Enum.Parse<PieceColor>(ps.GetProperty("Color").GetString()!)),
                    "Queen"  => new Queen(Enum.Parse<PieceColor>(ps.GetProperty("Color").GetString()!)),
                    "King"   => new King(Enum.Parse<PieceColor>(ps.GetProperty("Color").GetString()!)),
                    _        => null
                };
                if (newPiece == null) continue;

                if (newPiece is King king && ps.TryGetProperty("HasMoved", out var movedK))
                    king.HasMoved = movedK.GetBoolean();
                if (newPiece is Rook rook && ps.TryGetProperty("HasMoved", out var movedR))
                    rook.HasMoved = movedR.GetBoolean();

                gameBoard.Cells[r, c] = newPiece;
                occupied.Add((r, c));
            }

            // load turn
            currentTurn = Enum.Parse<PieceColor>(turnProp.GetString()!);

            // load en passant
            enPassantSquare = new Point(
                root.TryGetProperty("EnPassantX", out var ex) ? ex.GetInt32() : -1,
                root.TryGetProperty("EnPassantY", out var ey) ? ey.GetInt32() : -1
            );

            Invalidate();
        } catch (Exception ex) {
            MessageBox.Show("Failed to load game: " + ex.Message, "Load Error");
        }
    }

    // checks the end of the game situations
    void CheckEnd() {
        if (gameBoard.IsCheckmate(currentTurn)) {
            MessageBox.Show(currentTurn + " is checkmated!", "Checkmate");
            isGameOver = true;
        } else if (gameBoard.IsStalemate(currentTurn)) {
            MessageBox.Show("Stalemate!", "Draw");
            isGameOver = true;
        } else if (gameBoard.IsInsufficientMaterial()) {
            MessageBox.Show("Insufficient material!", "Draw");
            isGameOver = true;
        }
    }
}

//pawn promotion choice
public class Promotion : Form {
    public string SelectedPiece = "Queen";
    public Promotion(PieceColor c) {
        Text = "Promote Pawn";
        Size = new Size(420, 160);
        StartPosition = FormStartPosition.CenterParent;
        var names = new[] { "Queen", "Rook", "Bishop", "Knight" };
        for (int i = 0; i < 4; i++) {
            var button = new Button {
                Text = names[i],
                Size = new Size(100, 50),
                Location = new Point(10 + i * 105, 40)
            };
            button.Click += (s, e) => { SelectedPiece = button.Text; DialogResult = DialogResult.OK; };
            Controls.Add(button);
        }
    }
}
